import PageObject from 'ember-cli-page-object';
import { defaultsForApplication } from 'croodle/tests/pages/defaults';

export default PageObject.create(defaultsForApplication);
