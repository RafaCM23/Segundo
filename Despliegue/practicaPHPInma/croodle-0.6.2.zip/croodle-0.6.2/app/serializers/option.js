import classic from 'ember-classic-decorator';
import RESTSerializer from '@ember-data/serializer/rest';

@classic
export default class OptionSerializer extends RESTSerializer {}
