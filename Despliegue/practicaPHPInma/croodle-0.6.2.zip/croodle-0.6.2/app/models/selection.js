import answer from './answer';
export default answer;
