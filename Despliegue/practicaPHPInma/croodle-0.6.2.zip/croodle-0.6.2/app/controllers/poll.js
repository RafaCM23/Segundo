import { inject as service } from '@ember/service';
import { readOnly } from '@ember/object/computed';
import Controller from '@ember/controller';
import { isPresent, isEmpty } from '@ember/utils';
import { action, computed } from '@ember/object';
import { observes } from '@ember-decorators/object';
import moment from 'moment';

export default class PollController extends Controller {
  @service
  encryption;

  @service
  flashMessages;

  @service
  intl;

  @service
  router;

  queryParams = ['encryptionKey'];

  encryptionKey = '';
  timezoneChoosen = false;
  useLocalTimezone = false;

  @readOnly('intl.primaryLocale')
  currentLocale;

  @computed('currentLocale')
  get momentLongDayFormat() {
    let currentLocale = this.currentLocale;
    return moment.localeData(currentLocale)
      .longDateFormat('LLLL')
      .replace(
        moment.localeData(currentLocale).longDateFormat('LT'), '')
      .trim();
  }

  @readOnly('model')
  poll;

  @computed('router.currentURL', 'encryptionKey')
  get pollUrl() {
    return window.location.href;
  }

  @computed('poll.expirationDate')
  get showExpirationWarning() {
    let expirationDate = this.poll.expirationDate;
    if (isEmpty(expirationDate)) {
      return false;
    }
    return moment().add(2, 'weeks').isAfter(moment(expirationDate));
  }

  /*
   * return true if current timezone differs from timezone poll got created with
   */
  @computed('poll.timezone')
  get timezoneDiffers() {
    let modelTimezone = this.poll.timezone;
    return isPresent(modelTimezone) && moment.tz.guess() !== modelTimezone;
  }

  @computed('timezoneDiffers', 'timezoneChoosen')
  get mustChooseTimezone() {
    return this.timezoneDiffers && !this.timezoneChoosen;
  }

  @computed('useLocalTimezone')
  get timezone() {
    return this.useLocalTimezone ? undefined : this.poll.timezone;
  }

  @action
  linkAction(type) {
    let flashMessages = this.flashMessages;
    switch (type) {
      case 'copied':
        flashMessages.success(`poll.link.copied`);
        break;

      case 'selected':
        flashMessages.info(`poll.link.selected`);
        break;
    }
  }

  @action
  useLocalTimezone() {
    this.set('useLocalTimezone', true);
    this.set('timezoneChoosen', true);
  }

  // TODO: Remove this code. It's spooky.
  @observes('encryptionKey')
  preventEncryptionKeyChanges() {
    if (
      !isEmpty(this.encryption.key) &&
      this.encryptionKey !== this.encryption.key
    ) {
      // work-a-round for url not being updated
      window.location.hash = window.location.hash.replace(this.encryptionKey, this.encryption.key);

      this.set('encryptionKey', this.encryption.key);
    }
  }
}
