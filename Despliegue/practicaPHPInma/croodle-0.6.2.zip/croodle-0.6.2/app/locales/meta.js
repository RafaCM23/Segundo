export default {
  'ca': 'catalan',
  'de': 'deutsch',
  'en': 'english',
  'en-gb': 'english (GB)',
  'es': 'español',
  'it': 'italiano'
};
