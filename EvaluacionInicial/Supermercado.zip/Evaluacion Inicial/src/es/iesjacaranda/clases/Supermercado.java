package es.iesjacaranda.clases;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;


public class Supermercado {

	private String nombre;
	private HashSet<AbstractEmpleado> empleados;
	private HashSet<Producto> productos;
	
	
	/**
	 * @param nombre
	 */
	public Supermercado(String nombre) {
		super();
		this.nombre = nombre;
		this.empleados = new HashSet<AbstractEmpleado>();
		this.productos = new HashSet<Producto>();
	}
	
	/**
	 * Este metodo recibe un empleado y cambia el valor de encargado a true
	 * @param e  de tipo AbstractEmpleado
	 */
	public void hacerEncargado(AbstractEmpleado e) {
		for (AbstractEmpleado a : empleados) {
			if (a.equals(e)) {
				a.encargado(true);
			}
		}
	}

	
	
	/**
	 * Este metodo recibe un empleado y lo anade a la lista de empleados
	 * @param e de tipo AbstractEmpleado
	 * @return devuelve un String con el mensaje de exito o error
	 */
	public String addEmpleado(AbstractEmpleado e) {
		
		String respuesta="";
		if (empleados.contains(e)) {
			//Tambien se podria lanzar una excepcion pero voy a hacerlo por texto
			respuesta="Error: El empleado ya exite";
		}
		else {
			empleados.add(e);
			respuesta="Empleado añadido con exito";
		}
		return respuesta;
	}
	/**
	 * Este metodo recibe un producto y lo anade a la lista de productos
	 * @param p de tipo Producto
	 * @return Devuelve un String con el mensaje de exito o error
	 */
	public String addProducto(Producto p) {
		String respuesta="";
		if (productos.contains(p)) {
			respuesta="Error: El producto ya existe";
		}
		else {
			productos.add(p);
			respuesta="Producto añadido con exito";
		}
		return respuesta;
	}
	/**
	 * Este metodo recorre la lista de empleados y lo anade a un StringBuilder
	 * @return String 
	 */
	public String mostrarEmpleados() {
		
		StringBuilder respuesta= new StringBuilder();
		respuesta.append("Lista de empleados:\n");
		for (AbstractEmpleado e : empleados) {
			respuesta.append(e.toString()+"\n");
		}
		return respuesta.toString();
		}
	/**
	 * Este metodo recorre la lista de productos y los añade a un StringBuilder
	 * @return String
	 */
	public String mostrarProductos() {
		StringBuilder respuesta= new StringBuilder();
		respuesta.append("Lista de productos:\n");
		for (Producto p : productos) {
			respuesta.append(p.toString()+"\n");
		}
		return respuesta.toString();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public HashSet<AbstractEmpleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(HashSet<AbstractEmpleado> empleados) {
		this.empleados = empleados;
	}

	public HashSet<Producto> getProductos() {
		return productos;
	}

	public void setProductos(HashSet<Producto> productos) {
		this.productos = productos;
	}
	
	@Override
	public String toString() {
		StringBuilder respuesta = new StringBuilder();
		respuesta.append("\n"+this.ordenarEmpleados());
		respuesta.append("\n"+this.ordenarProductos());
	
		
		return respuesta.toString();
	}
	/**
	 * Este metodo ordena los productos por precio y lo devuelve en un String
	 * @return String 
	 */
	public String ordenarEmpleados() {
		ArrayList<AbstractEmpleado> array= new ArrayList<AbstractEmpleado>(empleados);
		array.sort(new ComparatorEmpleado());
		
		StringBuilder respuesta= new StringBuilder();
		
		respuesta.append("\n Lista de Empleados:\n");
		for(AbstractEmpleado a : array) {
			respuesta.append(a.toString()+"\n");
		}
		return respuesta.toString();
		}
	
	public String ordenarProductos() {
		ArrayList<Producto> array= new ArrayList<Producto>(this.productos);
		Collections.sort(array);
		
		StringBuilder respuesta = new StringBuilder();
		
		respuesta.append("\n Lista de productos:\n");
		for (Producto p : array) {
			respuesta.append(p.toString()+"\n");
		}
		
		return respuesta.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empleados == null) ? 0 : empleados.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((productos == null) ? 0 : productos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Supermercado other = (Supermercado) obj;
		if (empleados == null) {
			if (other.empleados != null)
				return false;
		} else if (!empleados.equals(other.empleados))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (productos == null) {
			if (other.productos != null)
				return false;
		} else if (!productos.equals(other.productos))
			return false;
		return true;
	}

	
	
}
