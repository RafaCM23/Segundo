package es.iesjacaranda.clases;


public abstract class AbstractEmpleado implements CalculaSueldo{

	
	private String nombre;
	private String dni;
	private int edad;
	private PuestosEnum puesto;
	private boolean encargado;
	
	/**
	 * @param nombre
	 * @param dni
	 * @param edad
	 * @param puesto
	 * @param encargado
	 */
	public AbstractEmpleado(String nombre, String dni, int edad, PuestosEnum puesto, boolean encargado) {
		super();
		this.nombre = nombre;
		this.dni = dni;
		this.edad = edad;
		this.puesto = puesto;
		this.encargado = encargado;
	}
	
	/**
	 * @param nombre
	 * @param dni
	 * @param edad
	 * @param puesto
	 */
	public AbstractEmpleado(String nombre, String dni, int edad, PuestosEnum puesto) {
		super();
		this.nombre = nombre;
		this.dni = dni;
		this.edad = edad;
		this.puesto = puesto;
		this.encargado = false;
	}
	
	/**
	 * @param Recive el puesto y se lo asigna al empleado
	 * @throws Exception si el puesto no existe
	 */
	public void setPuesto(PuestosEnum puesto) throws Exception {
		if (puesto == PuestosEnum.CAJERO) {
			this.puesto= PuestosEnum.CAJERO;
		}
		else if (puesto == PuestosEnum.REPONEDOR) {
			this.puesto= PuestosEnum.REPONEDOR;
		}
		else {
			throw new Exception("Ha habia un error al cambiar el puesto del trabajador");
			
		}
	}
	
	/**
	 * @param boolean cambia el valor de encargado al valor recibido (true/false)
	 * @return String con mensaje de exito o error
	 */
	public String encargado(boolean valor) {
		
		String respuesta="";
		if (valor != this.encargado) {
			this.encargado=valor;
			respuesta="Se ha actualizado el cargo del empleado";
		}
		else {
			respuesta="No se ha realizado ningun cambio";
		}
		
		return respuesta;
	}

	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	public String getDni() {
		return dni;
	}

	
	public void setDni(String dni) {
		this.dni = dni;
	}

	
	public int getEdad() {
		return edad;
	}

	
	public void setEdad(int edad) {
		this.edad = edad;
	}

	
	public boolean isEncargado() {
		return encargado;
	}


	
	public PuestosEnum getPuesto() {
		return puesto;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractEmpleado other = (AbstractEmpleado) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}

	
	@Override
	public String toString() {
		int sueldo=-1;
		try {
			sueldo = this.calcularSueldo();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "Nombre:" + nombre + " dni:" + dni + " edad:" + edad + " puesto:" + puesto
			+" sueldo:"+sueldo	+ " encargado: " + encargado ;
	}
	
	/**
	 * Este metodo devuelve el valor del sueldo segun el puesto del trabajador y de
	 * si es o no encargado
	 */
	public int calcularSueldo() throws Exception {
		int sueldo=0;
		if (this.puesto==PuestosEnum.CAJERO) {
			sueldo=PuestosEnum.CAJERO.getSueldo();
			if (this.encargado==true) {
				sueldo=(int) (sueldo*1.2);
			}
		}
		else if (this.puesto==PuestosEnum.REPONEDOR) {
			sueldo=PuestosEnum.REPONEDOR.getSueldo();
			if (this.encargado==true) {
				sueldo=(int) (sueldo*1.2);
			}
		}else {
			throw new Exception("Error: Revise el puesto del empleado");
		}
		
		return sueldo;
	}
	
	
	
}
