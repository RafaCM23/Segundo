package es.iesjacaranda.clases;

public interface CalculaSueldo {	
	
	public int calcularSueldo() throws Exception;
	public String imprimeSueldo();
}
