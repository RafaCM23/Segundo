package es.iesjacaranda.clases;

import java.util.Comparator;

public class ComparatorEmpleado implements Comparator<AbstractEmpleado> {

	public int compare(AbstractEmpleado a1, AbstractEmpleado a2) {
		int a=0;
		try {
			a=a1.calcularSueldo()-a2.calcularSueldo();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return a;
	}
}
