package es.iesjacaranda.clases;

public enum PuestosEnum {

	CAJERO(950),REPONEDOR(1050);
	
	private int sueldo;
	
	PuestosEnum(int s) {
		sueldo = s;
	}

	int getSueldo() {return sueldo;}
	
	
	
}
