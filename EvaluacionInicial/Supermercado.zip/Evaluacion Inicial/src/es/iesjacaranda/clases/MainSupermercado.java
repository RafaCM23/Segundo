package es.iesjacaranda.clases;

import java.util.Scanner;

public class MainSupermercado {

	
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner teclado = new Scanner(System.in);
		
		final String MENU="1.Crear Empleado \n"
				+ "2.Crear Producto \n"
				+ "3.Ver Empleados \n"
				+ "4.Ver Productos \n"
				+ "0. Salir \n" ;
		
		System.out.println("¿Quiere iniciar la aplicacion de creacion de supermercados? s/S");
		Character comienza= teclado.nextLine().charAt(0);
		if (comienza=='s' || comienza=='S') {
			
			System.out.println("¿Como se va a llamar?");
			String n=teclado.nextLine();
			while (n==null || n=="" || n.isEmpty()) {
				System.out.println("Introduzca un nombre");
				n=teclado.nextLine();
			}
			Supermercado s = new Supermercado(n);
			
			
			int res=-1;
			while (res!=0) {
				System.out.println("\n\n¿Que hacemos ahora?\n-------------------\n"+MENU);
				res= Integer.parseInt(teclado.nextLine());
				
				//Crear Empleado
				switch (res) {
				case 1:
					AbstractEmpleado e;
					System.out.println("Introduce los datos necesarios por orden:");
					
					System.out.println("1-Nombre");
					String nombre= teclado.nextLine();
					while (nombre==null || nombre=="" || nombre.isEmpty()) {
						System.out.println("Nombre invalido, intentelo de nuevo");
						nombre= teclado.nextLine();
					}
					
					System.out.println("2- dni");
					String dni = teclado.nextLine();
					while (dni.length()!=8 && dni.length()!=9) {//Contemplo dni con 8 o 9 digitos
						System.out.println("DNI invalido, introduzca un dni de 8-9 digitos");
						dni = teclado.nextLine();
					}
					
					System.out.println("3- edad");
					int edad = Integer.parseInt(teclado.nextLine());
					while (edad<16 || edad>67) {
						System.out.println("Edad invalida, intentelo de nuevo");
						edad = Integer.parseInt(teclado.nextLine());
					}
					
					
					System.out.println("¿De que trabajara el empleado? \n 1-Cajero \n 2-Reponedor");
					int puesto = Integer.parseInt(teclado.nextLine());
					while (puesto!=1 && puesto!=2) {
						System.out.println("Opcion invalida, intentelo de nuevo");
						puesto = Integer.parseInt(teclado.nextLine());
					}
					if (puesto==1) {
						 e= new EmpleadoCajero(nombre,dni,edad);
					}
					else {
						 e = new EmpleadoReponedor(nombre,dni,edad);
					}
					
					System.out.println("\n"+s.addEmpleado(e));
					
					System.out.println("¿Quieres hacerlo encargado s/n S/N?");
					Character sino= teclado.nextLine().charAt(0);
					while (sino!='S' && sino!='s' && sino!='n' && sino!='N') {
						System.out.println("Responda con s/n S/N");
						sino= teclado.nextLine().charAt(0);
						
						
					}
					if (sino=='S' || sino=='s') {
						s.hacerEncargado(e);
					}
					
					
					
					
					break;
					
					
					
					
				//Crear Producto
				case 2:
					String nom= null;
					System.out.println("\nNombre del producto:");
					nom=teclado.nextLine();
					while (nom==null || nom=="" || nom.isEmpty()) {
						System.out.println("Introduzca un nombre valido");
						nom=teclado.nextLine();
					}
					
					
					System.out.println("\nPrecio del producto:");
					 int precio=Integer.parseInt(teclado.nextLine());
					while (precio<1) {
						System.out.println("Introduzca un precio valido (a partir de 1€)");
						precio=Integer.parseInt(teclado.nextLine());
					}
					Producto p = new Producto(nom,precio);
					System.out.println(s.addProducto(p));
				
					break;
				//Ver Empleados
				case 3:
					System.out.println(s.mostrarEmpleados());
					break;
				//Ver Productos
				case 4:
					System.out.println(s.ordenarProductos());
					break;
				case 0:
					System.out.println(s.toString());
					System.out.println("\n Saliendo...");
					break;

				default:
					System.out.println("-Esa opcion no existe- \n");
					break;
				}
			}
			
		}
		else {
			System.out.println("Puede que otro dia...");
		}
		

	}

}
