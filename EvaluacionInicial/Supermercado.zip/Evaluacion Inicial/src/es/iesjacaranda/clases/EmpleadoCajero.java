package es.iesjacaranda.clases;

public class EmpleadoCajero extends AbstractEmpleado{

	private int caja;
	
	public EmpleadoCajero(String nombre, String dni, int edad) {
		super(nombre, dni, edad, PuestosEnum.CAJERO);
		
	}
	
	public EmpleadoCajero(String nombre, String dni, int edad, boolean encargado) {
		super(nombre, dni, edad, PuestosEnum.CAJERO, encargado);
		
	}

	public String setCaja(int caja) {
		
		String respuesta = "";
		
		if (caja>0 && caja<11 && caja!=this.caja) {
			this.caja=caja;
			respuesta="Se ha asignado esa caja con éxito";
			//Habria que averiguar algo para no poner a dos personas en la misma caja pero no voy
			//a complicarlo
		}
		else if (caja==this.caja) {
			respuesta="El empleado ya tiene asignada esa caja";
		}
		else {
			respuesta="Error al intentar asignar la caja al empleado";
		}
		return respuesta;
	}

	@Override
	public String imprimeSueldo() {
		return "Sueldo: "+this.imprimeSueldo()+"€";
	}

	
	

}
