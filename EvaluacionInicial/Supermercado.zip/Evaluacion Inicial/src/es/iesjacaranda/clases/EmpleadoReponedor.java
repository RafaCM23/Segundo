package es.iesjacaranda.clases;

public class EmpleadoReponedor extends AbstractEmpleado {

	private int area;
	
	public EmpleadoReponedor(String nombre, String dni, int edad) {
		super(nombre, dni, edad, PuestosEnum.REPONEDOR);
	}
	
	public EmpleadoReponedor(String nombre, String dni, int edad, boolean encargado) {
		super(nombre, dni, edad,PuestosEnum.REPONEDOR, encargado);
		
	}

	public String setArea(int area) {
		
		String respuesta="";
		if ((area>0) && area<9 && area!=this.area) {
			this.area=area;
			respuesta="Se ha asignado el area con exito";
		}
		else if (area==this.area) {
			respuesta="El empleado ya tiene asignada esa zona";
		}
		else {
			respuesta="Error al asignar la zona al empleado";
		}
		return respuesta;
	}
	
	@Override
	public String imprimeSueldo() {
		return "Sueldo: "+this.imprimeSueldo()+"€";
	}
}
